import pygame
import sounddevice as sd
import threading
import sys
import wave
import easygui as eg

# Initialize Pygame
pygame.init()

# Set up the screen
screen = pygame.display.set_mode((400, 300))
pygame.display.set_caption("Instrument Switcher")

# PITCH 0
piano_sounds_0 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A0.mp3"),    # A0  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B0.mp3"),          # B0  [S]
    #pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C0.mp3"),          # C0  [D]
    #pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D0.mp3"),          # D0  [F]
    #pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E0.mp3"),          # E0  [G]
    #pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F0.mp3"),          # F0  [H]
    #pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G0.mp3"),          # G0  [J]

    # Black Notes
    #pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab0.mp3"),         # C#0 [W]
    #pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C0.mp3"),         # D#0 [E]
    #pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db0.mp3"),         # F#0 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb0.mp3"),         # G#0 [Y]
    #pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb0.mp3"),         # A#0 [U]
}

# PITCH 1
piano_sounds_1 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A1.mp3"),    # A1  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B1.mp3"),          # B1  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C1.mp3"),          # C1  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D1.mp3"),          # D1  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E1.mp3"),          # E1  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F1.mp3"),          # F1  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G1.mp3"),          # G1  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab1.mp3"),         # C#1 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C1.mp3"),         # D#1 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db1.mp3"),         # F#1 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb1.mp3"),         # G#1 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb1.mp3"),         # A#1 [U]
}

# PITCH 2
piano_sounds_2 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A2.mp3"),    # A2  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B2.mp3"),          # B2  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C2.mp3"),          # C2  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D2.mp3"),          # D2  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E2.mp3"),          # E2  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F2.mp3"),          # F2  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G2.mp3"),          # G2  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab2.mp3"),         # C#2 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C2.mp3"),         # D#2 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db2.mp3"),         # F#2 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb2.mp3"),         # G#2 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb2.mp3"),         # A#2 [U]
}

# PITCH 3
piano_sounds_3 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A3.mp3"),    # A3  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B3.mp3"),          # B3  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C3.mp3"),          # C3  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D3.mp3"),          # D3  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E3.mp3"),          # E3  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F3.mp3"),          # F3  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G3.mp3"),          # G3  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab3.mp3"),         # C#3 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C3.mp3"),         # D#3 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db3.mp3"),         # F#3 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb3.mp3"),         # G#3 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb3.mp3"),         # A#3 [U]
}

# PITCH 4
piano_sounds_4 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A4.mp3"),    # A4  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B4.mp3"),          # B4  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C4.mp3"),          # C4  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D4.mp3"),          # D4  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E4.mp3"),          # E4  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F4.mp3"),          # F4  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G4.mp3"),          # G4  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab4.mp3"),         # C#4 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C4.mp3"),         # D#4 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db4.mp3"),         # F#4 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb4.mp3"),         # G#4 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb4.mp3"),         # A#4 [U]
}

# PITCH 5
piano_sounds_5 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A5.mp3"),    # A5  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B5.mp3"),          # B5  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C5.mp3"),          # C5  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D5.mp3"),          # D5  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E5.mp3"),          # E5  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F5.mp3"),          # F5  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G5.mp3"),          # G5  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab5.mp3"),         # C#5 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C5.mp3"),         # D#5 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db5.mp3"),         # F#5 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb5.mp3"),         # G#5 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb5.mp3"),         # A#5 [U]
}

# PITCH 6
piano_sounds_6 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A6.mp3"),    # A6  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B6.mp3"),          # B6  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C6.mp3"),          # C6  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D6.mp3"),          # D6  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E6.mp3"),          # E6  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F6.mp3"),          # F6  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G6.mp3"),          # G6  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab6.mp3"),         # C#6 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C6.mp3"),         # D#6 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db6.mp3"),         # F#6 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb6.mp3"),         # G#6 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb6.mp3"),         # A#6 [U]
}

# PITCH 7
piano_sounds_7 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/piano/A7.mp3"),    # A7  [A]
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/piano/B7.mp3"),          # B7  [S]
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/piano/C7.mp3"),          # C7  [D]
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/piano/D7.mp3"),          # D7  [F]
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/piano/E7.mp3"),          # E7  [G]
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/piano/F7.mp3"),          # F7  [H]
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/piano/G7.mp3"),          # G7  [J]

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/piano/Ab7.mp3"),         # C#7 [W]
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/piano/C7.mp3"),         # D#7 [E]
    pygame.K_f: pygame.mixer.Sound("files/sounds/instruments/piano/Db7.mp3"),         # F#7 [T]
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/piano/Bb7.mp3"),         # G#7 [Y]
    pygame.K_j: pygame.mixer.Sound("files/sounds/instruments/piano/Gb7.mp3"),         # A#7 [U]
}


# Load drum sounds
drum_sounds = {
    pygame.K_1: pygame.mixer.Sound("files/sounds/instruments/drum/cymbal.mp3"),
    pygame.K_2: pygame.mixer.Sound("files/sounds/instruments/drum/hi_hats.wav"),
    pygame.K_3: pygame.mixer.Sound("files/sounds/instruments/drum/kick.mp3"),
    pygame.K_4: pygame.mixer.Sound("files/sounds/instruments/drum/snare.wav"),
    pygame.K_5: pygame.mixer.Sound("files/sounds/instruments/drum/tom.mp3"),
    pygame.K_6: pygame.mixer.Sound("files/sounds/instruments/drum/floor_tom.wav"),
    pygame.K_7: pygame.mixer.Sound("files/sounds/instruments/drum/tom.mp3"),
    pygame.K_8: pygame.mixer.Sound("files/sounds/instruments/drum/hg_toms.wav"),
    pygame.K_9: pygame.mixer.Sound("files/sounds/instruments/drum/crash.wav"),
    pygame.K_0: pygame.mixer.Sound("files/sounds/instruments/drum/bass.wav")
}

guitar_sounds_2 = {
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/guitar/a2.wav"),      # A2
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/guitar/b2.wav"),      # B2
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/guitar/c2.wav"),      # C2
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/guitar/d2.wav"),      # D2
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/guitar/e2.wav"),      # E2
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/guitar/f2.wav"),      # F2
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/guitar/g2.wav"),      # G2

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/guitar/a#2.wav"),     # A#2
    pygame.K_s: pygame.mixer.Sound("files/sounds/instruments/guitar/c#2.wav"),     # C#2
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/guitar/d#2.wav"),     # D#2
    pygame.K_g: pygame.mixer.Sound("files/sounds/instruments/guitar/f#2.wav"),     # F#2
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/guitar/g#2.wav"),     # G#2
}

# PITCH 3 (Octave 3)
guitar_sounds_3 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/guitar/a3.wav"),    # A3
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/guitar/b3.wav"),         # B3
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/guitar/c3.wav"),         # C3
    pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/guitar/d3.wav"),         # D3
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/guitar/e3.wav"),         # E3
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/guitar/f3.wav"),         # F3
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/guitar/g3.wav"),         # G3

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/guitar/a#3.wav"),        # A#3
    pygame.K_s: pygame.mixer.Sound("files/sounds/instruments/guitar/c#3.wav"),        # C#3
    pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/guitar/d#3.wav"),        # D#3
    pygame.K_g: pygame.mixer.Sound("files/sounds/instruments/guitar/f#3.wav"),        # F#3
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/guitar/g#3.wav"),        # G#3
}

# PITCH 4 (Octave 4)
guitar_sounds_4 = {
    # White Notes
    pygame.K_LSHIFT: pygame.mixer.Sound("files/sounds/instruments/guitar/a4.wav"),    # A4
    pygame.K_z: pygame.mixer.Sound("files/sounds/instruments/guitar/b4.wav"),         # B4
    pygame.K_x: pygame.mixer.Sound("files/sounds/instruments/guitar/c4.wav"),         # C4
    #pygame.K_c: pygame.mixer.Sound("files/sounds/instruments/guitar/d4.wav"),         # D4
    pygame.K_v: pygame.mixer.Sound("files/sounds/instruments/guitar/e4.wav"),         # E4
    pygame.K_b: pygame.mixer.Sound("files/sounds/instruments/guitar/f4.wav"),         # F4
    pygame.K_n: pygame.mixer.Sound("files/sounds/instruments/guitar/g4.wav"),         # G4

    # Black Notes
    pygame.K_a: pygame.mixer.Sound("files/sounds/instruments/guitar/a#4.wav"),        # A#4
    #pygame.K_s: pygame.mixer.Sound("files/sounds/instruments/guitar/c#4.wav"),        # C#4
    #pygame.K_d: pygame.mixer.Sound("files/sounds/instruments/guitar/d#4.wav"),        # D#4
    pygame.K_g: pygame.mixer.Sound("files/sounds/instruments/guitar/f#4.wav"),        # F#4
    pygame.K_h: pygame.mixer.Sound("files/sounds/instruments/guitar/g#4.wav"),        # G#4
}

# Instrument key mapping
soundmap = {
    "piano": piano_sounds_5,
    "drum": drum_sounds,
    "guitar": guitar_sounds_2
}

piano_actions = {
    pygame.K_1: lambda: soundmap.__setitem__("piano", piano_sounds_0),
    pygame.K_2: lambda: soundmap.__setitem__("piano", piano_sounds_1),
    pygame.K_3: lambda: soundmap.__setitem__("piano", piano_sounds_2),
    pygame.K_4: lambda: soundmap.__setitem__("piano", piano_sounds_3),
    pygame.K_5: lambda: soundmap.__setitem__("piano", piano_sounds_4),
    pygame.K_6: lambda: soundmap.__setitem__("piano", piano_sounds_5),
    pygame.K_7: lambda: soundmap.__setitem__("piano", piano_sounds_6),
    pygame.K_8: lambda: soundmap.__setitem__("piano", piano_sounds_7),
}

guitar_actions = {
    pygame.K_1: lambda: soundmap.__setitem__("guitar", guitar_sounds_2),
    pygame.K_2: lambda: soundmap.__setitem__("guitar", guitar_sounds_3),
    pygame.K_3: lambda: soundmap.__setitem__("guitar", guitar_sounds_4),
}

drum_actions = {}

actionmap = {
    "piano": piano_actions,
    "drum": drum_actions,
    "guitar": guitar_actions
}

# Current instrument settings
instrument = "piano"  # Start with piano
is_mic_active = False

class AudioRecorder:
    def __init__(self, sample_rate=44100, channels=2):
        self.sample_rate = sample_rate
        self.channels = channels
        self.recording = False
        self.frames = []

    def start_recording(self):
        """Start the recording in a separate thread."""
        self.recording = True
        self.frames = []  # Reset frames for new recording
        self.thread = threading.Thread(target=self.record)
        self.thread.start()
        print("Recording started...")

    def record(self):
        """Record audio from the default input device."""
        with sd.InputStream(samplerate=self.sample_rate, channels=self.channels) as stream:
            while self.recording:
                data = stream.read(self.sample_rate // 10)[0]  # Read a small chunk of audio
                self.frames.append(data)

    def stop_recording(self):
        """Stop the recording."""
        try:
         self.recording = False
         self.thread.join()  # Wait for the recording thread to finish
         print("Recording stopped.")
        except Exception as e:
         print(e)

    def save_recording(self, save_path):
        """Save the recorded frames to a WAV file."""
        with wave.open(save_path, 'wb') as wf:
            wf.setnchannels(self.channels)
            wf.setsampwidth(2)  # 16 bits per sample
            wf.setframerate(self.sample_rate)
            wf.writeframes(b''.join(self.frames))
        print(f"Audio saved as {save_path}")

AudioRecorder = AudioRecorder()

def play_sound(sound):
    sound.play()

def stop_sound(sound):
    sound.stop()

def record_microphone():
    global is_mic_active
    is_mic_active = True
    # Record audio from the microphone
    while is_mic_active:
        print()
        #print("Recording from microphone...")  # Placeholder for actual audio processing

# Start the microphone recording in a separate thread
mic_thread = threading.Thread(target=record_microphone)
mic_thread.start()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_mic_active = False  # Stop the microphone recording
            pygame.quit()
            sys.exit()

        # Switch instruments with numpad keys
        if event.type == pygame.KEYDOWN:
            #if event.key == pygame.K_KP_7:
                #if AudioRecorder.recording:
            #        AudioRecorder.stop_recording()
                #elif not AudioRecorder.recording:
                #    AudioRecorder.start_recording()
            #elif event.key == pygame.K_KP_8:
                #AudioRecorder.save_recording(eg.filesavebox(title="Save the recording as a .wav file",msg="Save as .wav",default="Recording.wav"))
            #elif event.key == pygame.K_KP_9:
                #if AudioRecorder.recording:
                    #AudioRecorder.stop_recording()
                #elif not AudioRecorder.recording:
            #        AudioRecorder.start_recording()
            if event.key == pygame.K_KP_0:
                if is_mic_active:
                    is_mic_active = False
                    print("Microphone Off")
                elif is_mic_active:
                    is_mic_active = False
                    print("Microphone On")
            elif event.key == pygame.K_CAPSLOCK:
                instrument = eg.buttonbox(msg="Choose a instrument", title="Instrument selector", choices=["guitar", "piano", "drum"])
                print("Switched to", instrument)
            elif event.key == pygame.K_KP_1:
                instrument = "piano"
                print("Switched to Piano")
            elif event.key == pygame.K_KP_2:
                instrument = "drum"
                print("Switched to Drum")
            elif event.key == pygame.K_KP_3:
                instrument = "guitar"
                print("Switched to Guitar")

            # Play sound based on current instrument using the mapping directly
            if event.key in soundmap[instrument]:
                play_sound(soundmap[instrument][event.key])
            if event.key in actionmap[instrument]:
                actionmap[instrument][event.key]()

        if event.type == pygame.KEYUP:
            if event.key in soundmap[instrument]:
                stop_sound(soundmap[instrument][event.key])



    # Update the display
    pygame.display.flip()
